import * as React from "react";

export function Card({ children }) {
  return (
    <div className="bg-white shadow-md rounded-2xl border p-2">{children}</div>
  );
}

export function CardContent({ children, className = "" }) {
  return <div className={`p-4 ${className}`}>{children}</div>;
}