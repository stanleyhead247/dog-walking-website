"use client";

import React, { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";

export default function Home() {
  const [form, setForm] = useState({ name: "", email: "", message: "" });

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    alert("Booking request submitted! We'll contact you soon.");
    setForm({ name: "", email: "", message: "" });
  };

  return (
    <main className="p-4 md:p-8 max-w-4xl mx-auto">
      <section className="text-center mb-10">
        <h1 className="text-4xl font-bold mb-4">Paws & Walks</h1>
        <p className="text-lg">Reliable Dog Walking & Sitting in Burke, VA</p>
        <Button className="mt-6">Book a Walk</Button>
      </section>

      <section className="grid gap-6 mb-10">
        <Card>
          <CardContent className="p-4">
            <h2 className="text-2xl font-semibold mb-2">🐕 Services & Rates</h2>
            <ul className="list-disc list-inside">
              <li>30-Min Dog Walk: $20</li>
              <li>Overnight Sitting: $75</li>
              <li>Feeding, Playtime & More</li>
            </ul>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <h2 className="text-2xl font-semibold mb-2">💼 About Me</h2>
            <p>
              Hi! I'm M. Garbee, a lifelong animal lover with over 10 years of
              pet care experience. I treat every pet like family and proudly
              serve the Burke, VA community.
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <h2 className="text-2xl font-semibold mb-2">📞 Contact</h2>
            <p>Email: pawsandwalks@gmail.com</p>
            <p>Phone: (123) 456-7890</p>
            <p>Service Area: Burke, VA</p>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <h2 className="text-2xl font-semibold mb-2">📅 Booking Form</h2>
            <form onSubmit={handleSubmit} className="space-y-4">
              <Input
                type="text"
                name="name"
                placeholder="Your Name"
                value={form.name}
                onChange={handleChange}
                required
              />
              <Input
                type="email"
                name="email"
                placeholder="Your Email"
                value={form.email}
                onChange={handleChange}
                required
              />
              <Textarea
                name="message"
                placeholder="Tell us what you need (e.g. dates, services)"
                value={form.message}
                onChange={handleChange}
                required
              />
              <Button type="submit">Submit Booking Request</Button>
            </form>
          </CardContent>
        </Card>
      </section>
    </main>
  );
}